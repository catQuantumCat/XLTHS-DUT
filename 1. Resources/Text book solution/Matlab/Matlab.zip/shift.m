function [y,n]=shift(x,n,n0)
% function y=shift(x,n,n0)
% Dimitris Manolakis, February 2001

y=x; n=n-n0;